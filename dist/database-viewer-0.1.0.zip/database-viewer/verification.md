# Verification and delivery inventory

Recorded 2026-09-27. Development only; no production connection or deployment.

## Results

- PHP 8.4.26 / PHPUnit 12.5.33: **36 tests, 103 assertions, all passing**, no PHPUnit notices.
- Node 26.8.1 built-in test runner: **14 tests, all passing**.
- Laravel Pint: clean (`--test --quiet`).
- Generated baseline scaffold with beta38's real `p:plugin:make` command in a disposable local Panel copy.
- Installed final plugin sources using `php artisan p:plugin:install database-viewer` in that copy: **installed and enabled**.
- `php artisan route:list --name=database-viewer --except-vendor`: all three expected GET/assets, GET/viewer and POST/query routes registered through the normal plugin loader.
- Real Filament table construction test confirms the plugin action exists, its URL/visibility work, and core View/Delete actions remain.
- No real MariaDB server is required or used by automated tests. The executor is tested with PDO/MySqlConnector doubles; HTTP tests use real Panel models, policies and SQLite fixtures.
- Source and resource packaging uses an explicit allowlist, fixed timestamps, archive integrity check and a SHA-256 sidecar.
- Original Panel and Studio source checkouts have clean Git status. No core or Studio files were modified.
- An independent reviewer could not run because its usage allowance was exhausted; review was performed locally instead. No independent-review pass is claimed.

## Limits of these results

This proves the authorization, fixed-query execution wiring, message filtering, response conversion and plugin integration in tests. It does **not** prove a real private-network MariaDB connection, production compatibility, browser rendering, or the Studio UI displaying a result. The inspected Studio blocks its editor on schema-discovery failure. With transactions and schema queries explicitly excluded, that UI milestone remains blocked; see README for the separate recommended Studio probe-mode task and manual verification.

The MariaDB three-second statement timeout is sent as a PDO connection initialization command. Tests verify configuration but do not exercise a real server timeout or socket stall. No MySQL compatibility claim is made. Timed viewer expiry, explicit revocation controls and general SQL remain outside this release.

## All added plugin files

```text
database-viewer/
├── .gitignore
├── LICENSE
├── README.md
├── source-inspection.md
├── verification.md
├── plugin.json
├── phpunit.xml
├── config/
│   └── database-viewer.php
├── routes/
│   └── web.php
├── src/
│   ├── DatabaseViewerPlugin.php
│   ├── Providers/
│   │   └── DatabaseViewerPluginProvider.php
│   ├── Http/
│   │   └── ViewerController.php
│   └── Services/
│       ├── MariaDbExecutor.php
│       ├── QueryExecutor.php
│       ├── StudioOrigin.php
│       ├── ViewerAccess.php
│       └── ViewerContext.php
├── resources/
│   ├── js/
│   │   ├── bridge.mjs
│   │   └── viewer.mjs
│   └── views/
│       └── viewer.blade.php
└── tests/
    ├── bootstrap.php
    ├── bridge.test.mjs
    ├── StudioOriginTest.php
    └── ViewerTest.php
```

Other added files in the plugins workspace:

- `docs/superpowers/plans/2026-09-27-database-viewer.md`: implementation decisions and verification ledger.
- `tools/package-database-viewer.py`: deterministic allowlist packager.
- `dist/database-viewer-0.1.0.zip`: runtime/documentation release archive.
- `dist/database-viewer-0.1.0.zip.sha256`: archive checksum.

Existing file changed: root `README.md` adds the Database Viewer entry. No existing plugin files were changed. Plugin `.gitignore`, tests, phpunit.xml, plans, tools and test caches are excluded from the ZIP. The copied LICENSE is the existing plugins repository's GPLv3 license.
